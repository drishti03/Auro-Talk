package com.chatapp.aurotalk.Notifications;

public class MyResponse {

    public int success;
}
